<?php echo e($slot); ?>

<?php /**PATH C:\xampp1\htdocs\laravel2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>